#include "f2sw_dll_main.h"
#include <assert.h>
//#include <algorithm>
#include "detours.h"
#include "detours.h"
#include "hxdw/hxdw_utils.h"

F2SW_Data* F2swData2 = 0;  //extern

void f2sw_InitConfig()
{
	// read ini file, if any.
	std::string srIniFn;
	{
		std::string srDllFn = hxdw_GetModuleFileNameFromAddr( &f2sw_InitConfig );
		std::pair<std::string,std::string> pathp, basenamep;
		pathp     = hxdw_SplitPath( srDllFn );
		basenamep = hxdw_SplitExt( pathp.second );
		srIniFn = hxdw_PathJoin( pathp.first, basenamep.first, "ini" );
	}
	printf("F2SW: INI file: '%s'.\n", srIniFn.c_str() );
	if( !srIniFn.empty() && hxdw_FileExists( srIniFn.c_str() ) ){
		auto ini2 = hxdw_ParseINIFile( srIniFn.c_str() );
		std::string srHtk     = ini2.getValue("s_global", "szHotkey", "");
		std::string srIntrvls = ini2.getValue("s_global", "szIntervalsSnd", "");
		std::string srClr     = ini2.getValue("s_global", "szColorNeedle", "");
		std::string srXyOffs  = ini2.getValue("s_global", "szXyOffset", "");
		if( !srHtk.empty() ){
			std::vector<std::string> parts2;
			hxdw_StrExplode( srHtk.c_str(), parts2, {",",}, -1, "\t\x20");
			F2swData2->aHotkey.resize( parts2.size(), 0 );
			std::transform( parts2.begin(), parts2.end(), F2swData2->aHotkey.begin(),
						[](std::string s)->int{ return atoi(s.c_str()); } );
		}
		if( !srClr.empty() ){
			std::vector<std::string> parts2;
			hxdw_StrExplode( srClr.c_str(), parts2, {",",}, -1, "\t\x20");
			parts2.resize( 3, "0" );
			F2swData2->aColorNeedle.resize( 3, 0 );
			std::transform( parts2.begin(), parts2.end(), F2swData2->aColorNeedle.begin(),
						[](std::string s)->int{ return atoi(s.c_str()); } );
		}
		if( !srIntrvls.empty() ){
			std::vector<std::string> parts2;
			hxdw_StrExplode( srIntrvls.c_str(), parts2, {",",}, -1, "\t\x20");
			F2swData2->aIntervalsSnd.resize( parts2.size(), 0 );
			std::transform( parts2.begin(), parts2.end(), F2swData2->aIntervalsSnd.begin(),
						[](std::string s)->int{ return atoi(s.c_str()); } );
		}
		if( !srXyOffs.empty() ){
			std::vector<std::string> parts2;
			hxdw_StrExplode( srXyOffs.c_str(), parts2, {",",}, -1, "\t\x20");
			parts2.resize( 2, "0" );
			F2swData2->aXyOffset.resize( 2, 0 );
			std::transform( parts2.begin(), parts2.end(), F2swData2->aXyOffset.begin(),
						[](std::string s)->int{ return atoi(s.c_str()); } );
		}
	}
}

BOOL WINAPI DllMain( HINSTANCE, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			printf("F2SW: Process attach (%u).\n", (uint32_t)GetCurrentProcessId() );
			assert(!F2swData2);
			F2swData2 = new F2SW_Data;
			//
			f2sw_InitConfig();
			DetourTransactionBegin();
			DetourUpdateThread( GetCurrentThread() );
			DetourAttach( &(PVOID &)f2sw_OriTranslateMessage, f2sw_TranslateMessage );
			DetourTransactionCommit();
		}
		break;
	case DLL_PROCESS_DETACH:
		printf("F2SW: Process detach (%u).\n", (uint32_t)GetCurrentProcessId() );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &(PVOID &)f2sw_OriTranslateMessage, f2sw_TranslateMessage );
		DetourTransactionCommit();
		//
		assert(F2swData2);
		delete F2swData2;
		F2swData2 = 0;
		break;
	}
	return 1;
}
/// This is only for the dummy symbol name to be available for when patching
/// some executable.
int dll_dummy_xhb8uomq()
{
	return 42;
}

uint32_t f2sw_ThrSendDblClick( F2SW_ThrData* thdata )
{
	//GetDoubleClickTime()
	assert(F2swData2);
	const F2SW_ThrData tdx = *thdata;
	delete thdata;
	thdata = 0;
	POINT oldpos = {0,0,};
	GetCursorPos( &oldpos );
	SetCursorPos( tdx.pt5.x, tdx.pt5.y );
	//
	std::vector<int> irls = F2swData2->aIntervalsSnd;
	irls.resize( 3, 0 );
	hxdw_SendMouseButtonInput( {{MOUSEEVENTF_LEFTDOWN,0,},} );
	if( irls[0] )
		Sleep( irls[0] );
	hxdw_SendMouseButtonInput( {{MOUSEEVENTF_LEFTUP,0,},} );
	if( irls[1] )
		Sleep( irls[1] );
	hxdw_SendMouseButtonInput( {{MOUSEEVENTF_LEFTDOWN,0,},} );
	if( irls[2] )
		Sleep( irls[2] );
	hxdw_SendMouseButtonInput( {{MOUSEEVENTF_LEFTUP,0,},} );
	//
	SetCursorPos( oldpos.x, oldpos.y );
	return 0;
}
// Virtual-Key Codes
// https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
BOOL WINAPI f2sw_TranslateMessage( CONST MSG *lpMsg )
{
	if( lpMsg->message == WM_KEYDOWN ){
		assert( F2swData2 );
		std::vector<int>::const_iterator a,b;
		int key2 = (int)lpMsg->wParam;
		bool bF2sw = 0;
		a = std::find( F2swData2->aHotkey.begin(), F2swData2->aHotkey.end(), key2 );
		if( a != F2swData2->aHotkey.end() ){
			bool bOk = 1;
			for( b = F2swData2->aHotkey.begin(); b != F2swData2->aHotkey.end(); ++b ){
				if( !(GetKeyState(*b) & 0x8000) ){
					bOk = 0; break;
				}
			}
			if(bOk){
				bF2sw = 1;
			}
		}
		//if( lpMsg->wParam == VK_F2 ){}   // VK_F2: 0x71 = 113
		if( bF2sw ){
			HWND hwnd = GetForegroundWindow();
			POINT pt2 = {-1,-1,};
			hxdw_GetWindowPixels( hwnd, [&]( const RGBQUAD* pPixels2, int ww2, int hh2 ){
				// color_01: 64,0,128
				assert( F2swData2->aColorNeedle.size() == 3 );
				const std::vector<int>& clr = F2swData2->aColorNeedle;
				for( int y = 0; y < hh2; y++ ){
					for( int x = 0; x < ww2; x++ ){
						int p = (hh2-y-1) * ww2 + x;
						uint8_t r = pPixels2[p].rgbRed;
						uint8_t g = pPixels2[p].rgbGreen;
						uint8_t b = pPixels2[p].rgbBlue;
						if( r == clr[0] && g == clr[1] && b == clr[2] ){
							pt2 = { x, y,};
							y = hh2;   // cause 2nd break_.
							break;
						}
					}
				}
				return 1;
			});
			if( pt2.x != -1 ){
				RECT rct;
				GetWindowRect( hwnd, &rct );
				POINT pt3 = { pt2.x + rct.left, pt2.y + rct.top, };
				assert( F2swData2->aXyOffset.size() == 2 );
				pt3.x += F2swData2->aXyOffset[0];
				pt3.y += F2swData2->aXyOffset[1];
				F2SW_ThrData* ptr = new F2SW_ThrData;
				ptr->hwnd = hwnd;
				ptr->pt5  = pt3;
				CreateThread( 0, 0, (LPTHREAD_START_ROUTINE)f2sw_ThrSendDblClick, ptr, 0, 0 );
			}
		}
	}
	return f2sw_OriTranslateMessage( lpMsg );
}




//5IlvAt8Q6vlvHmwnH3bmRzJThHPkAGvqXm6FZm6CcsETtaX
