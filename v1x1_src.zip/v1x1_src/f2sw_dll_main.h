// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <string>
#include <windows.h>
//#include <commdlg.h>

extern "C" __declspec(dllexport) int dll_dummy_xhb8uomq();

//FindFirstFileA,FindNextFile
BOOL (WINAPI*  ori_FindNextFile)( HANDLE hFindFile, LPWIN32_FIND_DATA lpFindFileData ) = FindNextFile;
BOOL WINAPI    cksc_FindNextFile( HANDLE hFindFile, LPWIN32_FIND_DATA lpFindFileData );

//BOOL TranslateMessage(CONST MSG *lpMsg);
//BOOL (WINAPI*  _ori_TranslateMessage)(CONST MSG *lpMsg) = TranslateMessage;

//using _ori_TranslateMessage =//decltype()
using TranslateMessage_t = decltype(TranslateMessage)*;
TranslateMessage_t f2sw_OriTranslateMessage = TranslateMessage;
BOOL WINAPI        f2sw_TranslateMessage( CONST MSG *lpMsg );

//using d3dCrDASC_t = decltype(D3D11CreateDeviceAndSwapChain)*;
//d3dCrDASC_t d3dCrDASC = (d3dCrDASC_t)GetProcAddress( hD3dDll, "D3D11CreateDeviceAndSwapChain" );

struct F2SW_ThrData{
	HWND hwnd;
	POINT pt5;
};
struct F2SW_Data{
	std::vector<int> aHotkey = {113,};  // Eg. 113: F2
	std::vector<int> aColorNeedle = {255,0,255,};  //RGB: <rrr,ggg,bbb>
	std::vector<int> aIntervalsSnd = {16,0,16,};
	std::vector<int> aXyOffset = {0,0,};  //szXyOffset
};
extern F2SW_Data* F2swData2;








